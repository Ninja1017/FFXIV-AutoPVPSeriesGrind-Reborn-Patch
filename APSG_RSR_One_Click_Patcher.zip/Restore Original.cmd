@echo off
setlocal
chcp 65001 >nul
title Auto PVP Series Grind - Restore original DLL
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APSG-RSR-Patcher.ps1" -Restore -DllPath "%~1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Restore did NOT complete. Read the reason above.
echo Press any key to close this window.
pause >nul
exit /b %RESULT%
