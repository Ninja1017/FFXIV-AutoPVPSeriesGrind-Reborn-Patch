AUTO PVP SERIES GRIND - ONE-CLICK RSR PATCHER
=============================================
For Windows / XIVLauncher / Dalamud.

WHAT IT DOES
------------
- Allows Auto PVP Series Grind to load with Rotation Solver Reborn installed.
- Finds the latest installed AutoPvpSeriesGrind DLL automatically.
- Creates a timestamped backup of the original DLL first.
- Makes the SAME one-byte branch fix that worked in version 2.13.1.0.
- Recognizes an already-patched DLL and does not patch it twice.
- Refuses to modify unknown or changed method layouts rather than risking
  another InvalidProgramException.
- Needs only the Windows PowerShell that's already part of Windows.
  No Git, .NET SDK, Python, or administrator permission required.

HOW TO USE AFTER A FUTURE PLUGIN UPDATE
---------------------------------------
1. Close FFXIV completely.
2. Let Auto PVP Series Grind install its update normally.
3. Double-click "Patch AutoPvpSeriesGrind.cmd".
4. Look for "Patched successfully!" or "already patched".
5. Start FFXIV again.

If automatic detection fails, drag the correct AutoPvpSeriesGrind.dll file
from the new version folder onto "Patch AutoPvpSeriesGrind.cmd".

DEFAULT LOCATION
----------------
%APPDATA%\XIVLauncher\installedPlugins\AutoPvpSeriesGrind\<version>\AutoPvpSeriesGrind.dll

TO UNDO THE PATCH
-----------------
Close FFXIV and double-click "Restore Original.cmd". This restores
that version folder's most recent original DLL backup.

LIMITATION FOR FUTURE VERSIONS
------------------------------
This patcher works when the plugin continues to use the recognized
17-byte get_Blocked() method layout. If the developer changes the actual
compatibility-check instructions, the patcher WILL REFUSE TO CHANGE the
new DLL. This is intentional: guessing can break the plugin.

If you see "Safety stop", share the updated AutoPvpSeriesGrind.dll
(or full new plugin ZIP) so its new structure can be examined.

IMPORTANT
---------
- The game and launcher may overwrite modified DLLs on plugin updates.
- This only bypasses the plugin's RSR conflict gate; it cannot guarantee
  that two combat automation systems won't interfere with one another.
- Use at your own risk. No in-game validation is possible here.
- This package does NOT contain the plugin itself or game files.
