# Auto PVP Series Grind - Rotation Solver Reborn compatibility patcher
# No administrator privileges, .NET SDK, Git, or Python required.
# Tested byte pattern: AutoPvpSeriesGrind 2.13.1.0.
# IMPORTANT: Fail closed when a future build changes the layout.
[CmdletBinding()]
param(
    [string]$DllPath = '',
    [switch]$Restore
)

$ErrorActionPreference = 'Stop'
$ExpectedFile = 'AutoPvpSeriesGrind.dll'
$BackupPrefix = 'AutoPvpSeriesGrind.dll.before-rsr-patch.'

function Log-Info([string]$Message) { Write-Host ('[INFO] ' + $Message) -ForegroundColor Cyan }
function Log-Ok([string]$Message)   { Write-Host ('[ OK ] ' + $Message) -ForegroundColor Green }
function Fail([string]$Message)     { throw $Message }

function Find-TargetDll {
    param([string]$ExplicitPath)

    if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) {
        $path = [IO.Path]::GetFullPath($ExplicitPath.Trim([char]'"'))
        if ((Test-Path -LiteralPath $path -PathType Container)) {
            $path = Join-Path $path $ExpectedFile
        }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            Fail "DLL not found: $path"
        }
        if ([IO.Path]::GetFileName($path) -ine $ExpectedFile) {
            Fail "Select $ExpectedFile, not another DLL."
        }
        return $path
    }

    $pluginRoot = Join-Path $env:APPDATA 'XIVLauncher\installedPlugins\AutoPvpSeriesGrind'
    if (-not (Test-Path -LiteralPath $pluginRoot -PathType Container)) {
        Fail "Plugin folder not found: $pluginRoot`nDrag your AutoPvpSeriesGrind.dll onto 'Patch AutoPvpSeriesGrind.cmd' to select it manually."
    }

    $candidates = @(
        foreach ($folder in (Get-ChildItem -LiteralPath $pluginRoot -Directory)) {
            $path = Join-Path $folder.FullName $ExpectedFile
            if (Test-Path -LiteralPath $path -PathType Leaf) {
                try { $version = [version]$folder.Name }
                catch { $version = [version]'0.0' }
                [pscustomobject]@{
                    Path       = $path
                    Version    = $version
                    ModifiedAt = (Get-Item -LiteralPath $path).LastWriteTimeUtc
                }
            }
        }
    )
    if ($candidates.Count -eq 0) {
        Fail "No installed $ExpectedFile found under: $pluginRoot`nDrag the DLL onto 'Patch AutoPvpSeriesGrind.cmd' instead."
    }

    $sorted = @($candidates | Sort-Object -Property @{ Expression = { $_.Version }; Descending = $true }, @{ Expression = { $_.ModifiedAt }; Descending = $true })
    return $sorted[0].Path
}

function Find-SafePatchLocation {
    param([byte[]]$Data)

    # This pattern identifies a 17-byte, tiny-header get_Blocked() method:
    #   ldarg.0; call get_PluginLoaded; brtrue.s +7;
    #   ldarg.0; call get_DetectionFailed; ret; ldc.i4.1; ret
    # The two 4-byte method tokens may change from version to version.
    # Token ordering (first = second + 2) is checked to avoid changing
    # an unrelated or reversed boolean expression.
    $hits = New-Object 'System.Collections.Generic.List[object]'
    for ($i = 0; $i -le ($Data.Length - 18); $i++) {
        if ($Data[$i] -ne 0x46 -or $Data[$i+1] -ne 0x02 -or $Data[$i+2] -ne 0x28) { continue }
        if ($Data[$i+6] -ne 0x06 -or $Data[$i+7] -ne 0x2D) { continue }
        if ($Data[$i+8] -ne 0x07 -and $Data[$i+8] -ne 0x00) { continue }
        if ($Data[$i+9] -ne 0x02 -or $Data[$i+10] -ne 0x28 -or $Data[$i+14] -ne 0x06) { continue }
        if ($Data[$i+15] -ne 0x2A -or $Data[$i+16] -ne 0x17 -or $Data[$i+17] -ne 0x2A) { continue }

        $firstToken  = [BitConverter]::ToUInt32($Data, $i + 3)
        $secondToken = [BitConverter]::ToUInt32($Data, $i + 11)
        if ($firstToken -ne ($secondToken + 2)) { continue }

        $hits.Add([pscustomobject]@{ Offset = ($i + 8); Branch = $Data[$i+8] })
    }
    return $hits.ToArray()
}

function Confirm-PeAndSymbols {
    param([byte[]]$Data)
    if ($Data.Length -lt 1024 -or $Data[0] -ne 0x4D -or $Data[1] -ne 0x5A) {
        Fail 'The selected file is not a valid Windows DLL (missing MZ header).'
    }
    $peOffset = [BitConverter]::ToInt32($Data, 0x3C)
    if ($peOffset -lt 64 -or $peOffset -gt ($Data.Length - 4) -or
        $Data[$peOffset] -ne 0x50 -or $Data[$peOffset+1] -ne 0x45 -or
        $Data[$peOffset+2] -ne 0x00 -or $Data[$peOffset+3] -ne 0x00) {
        Fail 'The selected file has an invalid PE header.'
    }
    $stringData = [Text.Encoding]::ASCII.GetString($Data)
    foreach ($symbol in @('get_Blocked', 'get_PluginLoaded', 'get_DetectionFailed')) {
        if (-not $stringData.Contains($symbol)) {
            Fail "Expected method '$symbol' is missing. Refusing to patch an unknown plugin build."
        }
    }
}

function Replace-Atomically {
    param([string]$Target, [byte[]]$NewContents)
    $temp = Join-Path (Split-Path -Parent $Target) ('.apsg-rsr-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [IO.File]::WriteAllBytes($temp, $NewContents)
        $written = [IO.File]::ReadAllBytes($temp)
        if ($written.Length -ne $NewContents.Length) { Fail 'Temporary file size mismatch.' }
        # Windows same-volume atomic replacement. A file-in-use error is safe:
        # the original DLL remains untouched.
        [IO.File]::Replace($temp, $Target, $null)
    }
    finally {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
    }
}

Write-Host ''
Write-Host '========================================================' -ForegroundColor Magenta
Write-Host ' Auto PVP Series Grind - RSR compatibility patcher' -ForegroundColor Magenta
Write-Host '========================================================' -ForegroundColor Magenta
Write-Host ''

try {
    $running = @(Get-Process -Name 'ffxiv_dx11', 'ffxiv' -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
        Fail 'FFXIV is running. Close the game completely before patching or restoring the DLL.'
    }

    $target = Find-TargetDll -ExplicitPath $DllPath
    Log-Info "Target: $target"
    $folder = Split-Path -Parent $target

    if ($Restore) {
        $backups = @(Get-ChildItem -LiteralPath $folder -Filter ($BackupPrefix + '*.bak') -File |
            Sort-Object LastWriteTimeUtc -Descending)
        if ($backups.Count -lt 1) { Fail 'No original-DLL backup was found in this version folder.' }
        $backupFile = $backups[0].FullName
        Log-Info "Restoring: $backupFile"
        $bytes = [IO.File]::ReadAllBytes($backupFile)
        Confirm-PeAndSymbols -Data $bytes
        Replace-Atomically -Target $target -NewContents $bytes
        Log-Ok 'Original DLL restored. Your backup was kept.'
        exit 0
    }

    $original = [IO.File]::ReadAllBytes($target)
    Confirm-PeAndSymbols -Data $original
    $matches = @(Find-SafePatchLocation -Data $original)
    if ($matches.Count -ne 1) {
        Fail "Safety stop: found $($matches.Count) matching compatibility methods; expected exactly 1. This update changed the DLL layout, so nothing was modified. Supply the new DLL to make an updated patcher."
    }

    $offset = [int]$matches[0].Offset
    if ($matches[0].Branch -eq 0x00) {
        Log-Ok 'This version is already patched. No changes are necessary.'
        exit 0
    }
    if ($matches[0].Branch -ne 0x07) {
        Fail 'Safety stop: unexpected branch value. Nothing was modified.'
    }

    # Backup first, then change exactly one branch offset: 07 -> 00.
    $stamp = (Get-Date).ToString('yyyyMMdd-HHmmss-fff')
    $backupPath = Join-Path $folder ($BackupPrefix + $stamp + '.bak')
    [IO.File]::WriteAllBytes($backupPath, $original)
    if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) { Fail 'Could not create backup.' }
    Log-Ok "Original backed up: $backupPath"

    $changed = [byte[]]$original.Clone()
    $changed[$offset] = 0x00
    if ($changed.Length -ne $original.Length) { Fail 'Safety stop: patched size mismatch.' }
    $diffCount = 0
    for ($j = 0; $j -lt $original.Length; $j++) {
        if ($original[$j] -ne $changed[$j]) { $diffCount++ }
    }
    if ($diffCount -ne 1) { Fail 'Safety stop: patch would change more than one byte.' }

    Replace-Atomically -Target $target -NewContents $changed
    $final = [IO.File]::ReadAllBytes($target)
    $finalMatch = @(Find-SafePatchLocation -Data $final)
    if ($final.Length -ne $original.Length -or $finalMatch.Count -ne 1 -or $finalMatch[0].Branch -ne 0x00) {
        Fail 'The post-patch integrity check failed. Restore the original using Restore Original.cmd.'
    }

    Log-Ok ('Patched successfully! Changed only the branch byte at 0x{0:X}.' -f $offset)
    Log-Ok 'Rotation Solver Reborn loading no longer triggers this compatibility block.'
    Write-Host 'This does not guarantee simultaneous combat control will be conflict-free.' -ForegroundColor Yellow
    exit 0
}
catch {
    Write-Host ''
    Write-Host ('[FAILED] ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
