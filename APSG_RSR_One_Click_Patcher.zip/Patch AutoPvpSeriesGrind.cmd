@echo off
setlocal
chcp 65001 >nul
title Auto PVP Series Grind - Patch for Rotation Solver Reborn
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APSG-RSR-Patcher.ps1" -DllPath "%~1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Patch was NOT applied. Read the reason above.
echo Press any key to close this window.
pause >nul
exit /b %RESULT%
